import React from 'react';
import Button from '../UI/Button';

interface BottomBarProps {
    macroStatus: string;
    onStartMacro: () => void;
    onStopMacro: () => void;
}

const BottomBar: React.FC<BottomBarProps> = ({ macroStatus, onStartMacro, onStopMacro }) => {
    return (
        <div className="h-16 bg-background-secondary border-t border-white/5 px-6 flex items-center justify-between flex-shrink-0 z-20">
            {/* Status Indicator */}
            <div className="flex items-center gap-4">
                <div className="flex items-center gap-2">
                    <span className="text-sm font-bold text-text-secondary uppercase tracking-wider">Status</span>
                    <div className={`flex items-center gap-2 px-3 py-1 rounded-full border ${macroStatus === 'started'
                            ? 'bg-status-success/10 border-status-success/20 text-status-success'
                            : 'bg-status-error/10 border-status-error/20 text-status-error'
                        }`}>
                        <span className={`w-2 h-2 rounded-full ${macroStatus === 'started' ? 'bg-status-success animate-pulse' : 'bg-status-error'}`} />
                        <span className="text-xs font-bold">{macroStatus.toUpperCase()}</span>
                    </div>
                </div>
            </div>

            {/* Controls */}
            <div className="flex items-center gap-4">
                <Button
                    onClick={onStartMacro}
                    disabled={macroStatus === 'started'}
                    variant="primary"
                    className="w-32"
                    icon={
                        <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z" />
                        </svg>
                    }
                >
                    Start (F1)
                </Button>

                <Button
                    onClick={onStopMacro}
                    disabled={macroStatus !== 'started'}
                    variant="danger"
                    className="w-32"
                    icon={
                        <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 10a1 1 0 011-1h4a1 1 0 011 1v4a1 1 0 01-1 1h-4a1 1 0 01-1-1v-4z" />
                        </svg>
                    }
                >
                    Stop (F3)
                </Button>
            </div>

            {/* Extra Info / Credits */}
            <div className="flex items-center gap-4 text-xs text-text-muted">
                <span>BSSAI</span>
                <span className="w-1 h-1 rounded-full bg-white/20" />
                <span>v0.0.2</span>
                <span className="w-1 h-1 rounded-full bg-white/20" />
                <div className="flex items-center gap-2">
                    <a
                        href="https://github.com/BSS-AI/BSS-AI"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="p-1.5 rounded-md hover:bg-white/5 transition-colors group"
                        title="GitHub"
                    >
                        <svg className="w-4 h-4 text-text-muted hover:text-text-primary transition-colors" viewBox="0 0 24 24" fill="currentColor">
                            <path d="M12 0c-6.626 0-12 5.373-12 12 0 5.302 3.438 9.8 8.207 11.387.599.111.793-.261.793-.577v-2.234c-3.338.726-4.033-1.416-4.033-1.416-.546-1.387-1.333-1.756-1.333-1.756-1.089-.745.083-.729.083-.729 1.205.084 1.839 1.237 1.839 1.237 1.07 1.834 2.807 1.304 3.492.997.107-.775.418-1.305.762-1.604-2.665-.305-5.467-1.334-5.467-5.931 0-1.311.469-2.381 1.236-3.221-.124-.303-.535-1.524.117-3.176 0 0 1.008-.322 3.301 1.23.957-.266 1.983-.399 3.003-.404 1.02.005 2.047.138 3.006.404 2.291-1.552 3.297-1.23 3.297-1.23.653 1.653.242 2.874.118 3.176.77.84 1.235 1.911 1.235 3.221 0 4.609-2.807 5.624-5.479 5.921.43.372.823 1.102.823 2.222v3.293c0 .319.192.694.801.576 4.765-1.589 8.199-6.086 8.199-11.386 0-6.627-5.373-12-12-12z"/>
                        </svg>
                    </a>
                    <a
                        href="https://discord.gg/bssai"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="p-1.5 rounded-md hover:bg-white/5 transition-colors group"
                        title="Discord"
                    >
                        <svg className="w-4 h-4 text-text-muted hover:text-[#5865F2] transition-colors" viewBox="0 0 24 24" fill="currentColor">
                            <path d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515a.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0a12.64 12.64 0 0 0-.617-1.25a.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057a.082.082 0 0 0 .031.057a19.9 19.9 0 0 0 5.993 3.03a.078.078 0 0 0 .084-.028a14.09 14.09 0 0 0 1.226-1.994a.076.076 0 0 0-.041-.106a13.107 13.107 0 0 1-1.872-.892a.077.077 0 0 1-.008-.128a10.2 10.2 0 0 0 .372-.292a.074.074 0 0 1 .077-.01c3.928 1.793 8.18 1.793 12.062 0a.074.074 0 0 1 .078.01c.12.098.246.198.373.292a.077.077 0 0 1-.006.127a12.299 12.299 0 0 1-1.873.892a.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028a19.839 19.839 0 0 0 6.002-3.03a.077.077 0 0 0 .032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.03zM8.02 15.33c-1.183 0-2.157-1.085-2.157-2.419c0-1.333.956-2.419 2.157-2.419c1.21 0 2.176 1.096 2.157 2.42c0 1.333-.956 2.418-2.157 2.418zm7.975 0c-1.183 0-2.157-1.085-2.157-2.419c0-1.333.955-2.419 2.157-2.419c1.21 0 2.176 1.096 2.157 2.42c0 1.333-.946 2.418-2.157 2.418z"/>
                        </svg>
                    </a>
                    <a
                        href="https://bss-ai.com"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="p-1.5 rounded-md hover:bg-white/5 transition-colors group"
                        title="Website"
                    >
                        <svg className="w-4 h-4 text-text-muted hover:text-text-primary transition-colors" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                            <circle cx="12" cy="12" r="10"></circle>
                            <line x1="2" y1="12" x2="22" y2="12"></line>
                            <path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"></path>
                        </svg>
                    </a>
                </div>
            </div>
        </div>
    );
};

export default BottomBar;
